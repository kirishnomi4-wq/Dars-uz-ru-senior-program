
// ============================================================
//  8 · Hodisa: tranzaksiyadan keyin, ichida faqat «nima o'zgardi» (telegram.service.ts, admin.controller.ts)
// ============================================================
const TG = { pl: lineN('TG', /await this\.orders\.place\(/), st: lineN('TG', /await this\.orders\.setStatus\(/) };
const TG_EMIT_NEW = lineN('TG', /orderChanged\(order\.id, 'new'\)/), TG_EMIT_ST = lineN('TG', /orderChanged\(order\.id, 'status'\)/);
const CT = { list: lineN('CTRL', /@Get\('orders'\)/) };
const S8 = mkS(8, [{ v: 'pl' }, { v: 'st' }, { v: 'flow' }, { v: 'ctrl' }]);
function Screen8(p) {
  return <Lesson p={p} S={S8} scene={({ seg }) => <>
    {seg.v === 'pl' && <Code k="TG" ids={{ [TG.pl]: 'a', [TG_EMIT_NEW]: 'e', [TG_EMIT_NEW - 1]: 'e' }} from={TG.pl - 3} to={TG_EMIT_NEW + 2} focus={['a', 'e']} />}
    {seg.v === 'st' && <CodePanel file={t("telegram.service.ts · status tugmasi", "telegram.service.ts · кнопка статуса")} lines={kod('TG', { [TG.st]: 'a', [TG_EMIT_ST]: 'e' }, TG.st, TG_EMIT_ST + 1)} focus={['a', 'e']} />}
    {seg.v === 'flow' && <div style={{ display: 'grid', gap: 10 }}><Flow hl={['tx', 'ev', 'get']} /><div className="mk-rule">{t("Hodisada ", "В событии ")}<b>{t("faqat", "только")}</b> <code>orderId</code>{t(" va ", " и ")}<code>reason</code>{t(" — ro'yxat ham, telefon ham yo'q. Ma'lumot manbai bitta: baza (token bilan ", " — нет ни списка, ни телефона. Источник данных один: база (с токеном ")}<code>GET</code>).</div></div>}
    {seg.v === 'ctrl' && <Code k="CTRL" ids={rngIds(CT.list, CT.list + 16, 'l')} from={CT.list - 2} to={CT.list + 16} focus={['l']} />}
  </>} />;
}

// ============================================================
//  9 · Panel sahifasi: ulanish, tinglovchi, qayta so'rash (public/admin.html)
// ============================================================
const H = { scr: lineN('HTML', /socket\.io\/socket\.io\.js"><\/script>/), yk: lineN('HTML', /async function yukla/), ul: lineN('HTML', /function ulan\(\)/), on: lineN('HTML', /ulanish\.on\('order-changed'/), esc: lineN('HTML', /const esc =/), escU: lineN('HTML', /esc\(o\.customer\)/) };
const S9 = mkS(9, [{ v: 'scr' }, { v: 'ul', f: ['i', 'c'] }, { v: 'ul', f: ['o'] }, { v: 'esc' }]);
function Screen9(p) {
  return <Lesson p={p} S={S9} scene={({ seg }) => <>
    {seg.v === 'scr' && <Code k="HTML" ids={{ [H.scr]: 's', [H.scr - 1]: 's', [H.yk + 1]: 'f' }} from={H.scr - 1} to={H.yk + 1} focus={['s', 'f']} fresh={F.html} />}
    {seg.v === 'ul' && <Code k="HTML" ids={{ [H.ul + 2]: 'i', [H.ul + 4]: 'c', [H.ul + 6]: 'c', [H.on]: 'o' }} from={H.ul} to={H.on + 1} focus={seg.f} />}
    {seg.v === 'esc' && <CodePanel file="admin.html" lines={[...kod('HTML', { [H.esc]: 'e' }, H.esc - 1, H.esc), { h: '<span class="cm">…</span>', n: '' }, ...kod('HTML', { [H.escU]: 'e' }, H.escU, H.escU + 1)]} focus={['e']} />}
  </>} />;
}

// ============================================================
//  10 · Haqiqiy oqim: bot → server → panel (10-panel, 04, 12)
// ============================================================
const T10CLI = outPick('04', (l) => /order-changed|connect · ulangan/.test(l));
const T10SRV = outPick('04', (l) => /\[Live\] panel ulandi|— Bobur|qabul qilindi|— admin|Tasdiqlangan$/.test(l)).slice(0, 6);
const T10CI = outPick('12', (l) => /✓ (test|smoke) in|— live|✓ (tokensiz|yangi|GET|admin)|NATIJA/.test(l));
const S10 = mkS(10, [{ k: '10a' }, { k: '10b' }, { k: '10c', cli: true }, { ci: true }]);
function Screen10(p) {
  return <Lesson p={p} S={S10} scene={({ seg }) => <>
    {!seg.ci && !seg.cli && <PanelView k={seg.k} note={seg.k === '10a' ? t('token kiritildi — ro\'yxat GET /admin/orders dan', "токен введён — список из GET /admin/orders") : t('bot buyurtma oldi — sahifa yangilanmadi', "бот получил заказ — страница не обновилась")} />}
    {seg.cli && <div style={{ display: 'grid', gap: 8 }} className="c1-small"><PanelView k="10c" small note={t("admin tasdiqladi", "админ подтвердил")} /><div className="pg-two"><Term title="npm run live" lines={T10CLI} /><Term title={t("server logi", "лог сервера")} lines={T10SRV} /></div></div>}
    {seg.ci && <Term title="GitHub Actions · main · ws1-done (run 41856397400)" lines={T10CI} />}
  </>} />;
}

// ============================================================
//  11 · Tekshiruv 2 — LineCheck: () => yukla qavssiz (admin.html ulan(), 11b)
// ============================================================
const LC11 = KOD.HTML.lines.filter((l) => l.n >= H.ul && l.n <= H.on).map((l) => ({ h: tsLine(l.n === H.on ? l.t.replace('() => yukla())', '() => yukla)') : l.t), n: l.n }));
const LC11_FIXED = KOD.HTML.lines.filter((l) => l.n >= H.ul && l.n <= H.on).flatMap((l) => l.n === H.on ? [{ h: tsLine(l.t.replace('() => yukla())', '() => yukla)')), n: l.n, gone: true }, { h: tsLine(l.t), n: l.n, neu: true }] : [{ h: tsLine(l.t), n: l.n }]);
const T11X = [...txtLines(KOD.OUT['11b'].split('# brauzer')[1].split('#')[0]).filter((x) => !/^\s*$/.test(x.h)), ...outPick('11b', (l) => /order-changed/.test(l))];
function Screen11(p) {
  const m = MDT[11];
  return <LineCheck {...p} kicker={m.kicker} eyebrow={m.eyebrow} title={m.title} task={m.task} q={m.q} file="admin.html · ulan()" lines={LC11} target={LC11.length - 1}
    fixed={LC11_FIXED} fixedExtra={[{ file: t("brauzer (qavssiz) · 15 s — ro'yxat o'zgarmadi; o'sha paytda npm run live", "браузер (без скобок) · 15 с — список не изменился; в это же время npm run live"), lines: T11X }]}
    ok={m.ok} okShort={<span dangerouslySetInnerHTML={html(m.okShort)} />} hint={m.hint} />;
}

// ============================================================
//  12 · Amaliyot 2 — brauzerda panel va bot
// ============================================================
const P12 = mkPractice(12, [[], [0, 1], [2, 3], []], { code: [{ step: 0, file: F.html, lines: kod('HTML', {}, H.ul, H.on + 1), copy: false }] });
function ScreenP12(p) { return <Practice p={p} S={P12.S} steps={P12.steps} trouble={P12.trouble} proof={P12.proof} code={P12.code} tree={FILES()} />; }

// ============================================================
//  13 · Uch holat (03, 05, 06, 10d, 10e)
// ============================================================
const S13 = mkS(13, [{ on: 0 }, { on: 1 }, { on: 2 }, { sum: true }]);
function Screen13(p) {
  return <Lesson p={p} S={S13} scene={({ seg }) => <>
    {!seg.sum && <><States on={seg.on} />{seg.on === 1 && <div style={{ marginTop: 10 }}><PanelView k="10d" small note={t("server to'xtatildi — ro'yxat ekranda qoladi", "сервер остановлен — список остаётся на экране")} /></div>}{seg.on === 2 && <div style={{ marginTop: 10 }}><PanelView k="10e" small note={t("ikkinchi oyna — token «notogri»", "второе окно — токен «notogri»")} /></div>}</>}
    {seg.sum && <div style={{ display: 'grid', gap: 10 }}><States /><CodePanel file="admin.html" lines={kod('HTML', { [H.ul + 6]: 'd', [H.ul + 7]: 'd' }, H.ul + 5, H.ul + 7)} focus={['d']} /></div>}
  </>} />;
}

// ============================================================
//  14 · Server o'chdi va qayta yondi (05)
// ============================================================
const L05 = outLines('05');
const T14A = outRange('05', /^\$ npm run live/, /disconnect: transport close/);
const T14B = outRange('05', /disconnect: transport close/, /connect · ulangan · transport: polling/);
const T14C = outRange('05', /^\$ npm run live/, null);
const STOPAT = (L05.find((l) => /server to'xtatildi/.test(l)) || '').slice(0, 8), STARTAT = (L05.find((l) => /qayta ishga/.test(l)) || '').slice(0, 8);
const S14 = mkS(14, [{ v: 'a' }, { v: 'b' }, { v: 'c' }, { v: 'q' }]);
function Screen14(p) {
  return <Lesson p={p} S={S14} scene={({ seg }) => <>
    {seg.v === 'a' && <Term title={t(`npm run live · ${STOPAT} — server to'xtatildi (Ctrl+C)`, `npm run live · ${STOPAT} — сервер остановлен (Ctrl+C)`)} lines={T14A.concat(T14B.slice(0, 1))} />}
    {seg.v === 'b' && <Term title={t("npm run live · qayta urinishlar", "npm run live · повторные попытки")} lines={T14B} />}
    {seg.v === 'c' && <Term title={t(`npm run live · ${STARTAT} — server qayta ishga tushirildi`, `npm run live · ${STARTAT} — сервер снова запущен`)} lines={T14C} />}
    {seg.v === 'q' && <div className="pg-two"><PanelView k="10d" small note={t("server o'chgan payt", "момент, когда сервер выключен")} /><Card c={C1.live} h={t("Savol — WebSocket-2", "Вопрос — WebSocket-2")}><p>{t("Server o'chiq paytida bot buyurtma olsa, panel qayta ulanganda uni ", "Если бот получил заказ, пока сервер был выключен, панель при переподключении ")}<b>{t("ko'radimi", "увидит его")}</b>{t("? Hodisa o'sha paytda hech kimga yetmagan.", "? Событие в тот момент ни до кого не дошло.")}</p></Card></div>}
  </>} />;
}

// ============================================================
//  15 · «Muzlash»: 45 soniya javobsiz (06)
// ============================================================
const L06 = outLines('06');
const FRZ = (L06.find((l) => /muzlatildi/.test(l)) || '').slice(0, 8), PTO = (L06.find((l) => /ping timeout/.test(l)) || '').slice(0, 8), CONT = (L06.find((l) => /davom ettirildi/.test(l)) || '').slice(0, 8);
const secs = (a, b) => { const s = (x) => x.split(':').reduce((t, v) => t * 60 + Number(v), 0); return a && b ? s(b) - s(a) : 0; };
const T15 = outRange('06', /^\$ npm run live/, /^# 45/);
const S15 = mkS(15, [{ v: 'frz' }, { v: 'wait' }, { v: 'ping' }, { v: 'sum' }]);
function Screen15(p) {
  const line = <div className="c1-flow"><div style={{ '--c': C1.live }}><b>{FRZ}</b><small>{t("muzlatildi (kill -STOP)", "заморожен (kill -STOP)")}</small></div><span className="ar">→</span><div style={{ '--c': T.ink3 }}><b>+{secs(FRZ, PTO)} s</b><small>{t("javob yo'q — belgi «Ulangan»", "ответа нет — знак «Ulangan»")}</small></div><span className="ar">→</span><div style={{ '--c': T.accent }}><b>{PTO}</b><small>ping timeout</small></div><span className="ar">→</span><div style={{ '--c': T.green }}><b>{CONT}</b><small>{t("davom — darhol ulandi", "продолжение — сразу подключился")}</small></div></div>;
  return <Lesson p={p} S={S15} scene={({ seg }) => <>
    {seg.v === 'frz' && <Term title="npm run live" lines={T15.slice(0, 3)} />}
    {seg.v === 'wait' && <div style={{ display: 'grid', gap: 10 }}><Term title="npm run live" lines={T15.slice(0, 3)} />{line}</div>}
    {seg.v === 'ping' && <div className="pg-two"><Term title="npm run live" lines={T15} /><Card c={C1.ws} h={t("ping qoidasi (socket.io standarti)", "правило ping (стандарт socket.io)")}><p>{t("Server har ", "Сервер каждые ")}<b>25 s</b>{t(" ping yuboradi → klient javob beradi.", " шлёт ping → клиент отвечает.")}</p><p><b>20 s</b>{t(" ichida javob yo'q — ulanish o'lik: ", " нет ответа — соединение мертво: ")}<code>ping timeout</code>.</p><p>{t("Eng uzog'i — ", "Самое долгое — ")}<b>45 s</b>.</p></Card></div>}
    {seg.v === 'sum' && <div style={{ display: 'grid', gap: 10 }}>{line}<div className="n2-warn">{t("Javob yo'qligi — uzilish emas: tarmoq javob bermasa, hech kim aytmaydi. Ulanish o'lganini ", "Отсутствие ответа — не обрыв: если сеть не отвечает, никто об этом не скажет. Что соединение умерло, определяет ")}<b>{t("faqat ping", "только ping")}</b>{t(" aniqlaydi — 45 s gacha kechikib.", " — с задержкой до 45 s.")}</div></div>}
  </>} />;
}

// ============================================================
//  16 · Tekshiruv 3 — server javob bermasa (06)
// ============================================================
function Screen16(p) {
  return MC(p, 16, {
    above: <Term title={t("npm run live · server muzlatildi", "npm run live · сервер заморожен")} lines={['connect · ulangan · transport: polling', 'muzlatildi', 'ping timeout'].map((w) => outPick('06', (l) => l.includes(w))[0]).filter(Boolean)} />,
    after: <Term title="npm run live" lines={T15} />,
  });
}
