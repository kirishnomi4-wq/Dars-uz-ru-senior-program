
// ============================================================
//  1 · Kirish — dars oxiridagi natija: main'dagi PR merge run'i (37): test + smoke
// ============================================================
const PLAN1 = ['Umumiy tushuncha', "Qizilni o'qish va cache", 'matrix', 'Smoke va secret', 'PR va AI', 'Sinfga tayyorgarlik'];
const S1 = mkS(1, [{ hl: [], res: true }, { hl: [0, 1] }, { hl: [2, 3, 4, 5] }, { hl: [5] }], { plan: PLAN1 });
function Screen1(p) {
  return <Lesson p={p} S={S1} scene={({ seg }) => <div style={{ display: 'grid', gap: 14 }}>
    <div className="mk-light"><div className="mk-plan">
      {S1.plan.map((x, i) => <div key={i} className={seg.hl.includes(i) ? 'hl' : (seg.hl.length ? 'dim' : '')}><b>0{i + 1}</b><span>{x}</span></div>)}
    </div></div>
    {seg.res && <><div className="mk-tag" style={{ margin: 0 }}>{t("Dars oxirida — main'da ikki job: test va smoke (Postgres bilan)", "В конце урока — в main две job: test и smoke (с Postgres)")}</div><RunView k="37" job="smoke" only={/Initialize|npm ci|npm run smoke|Stop/} /></>}
  </div>} />;
}

// ============================================================
//  2 · Actions nima qiladi: run → job → step, GitHub qo'shgan qadamlar (run 10 — Post'lar bilan)
// ============================================================
const GH_STEPS = ['Set up job', 'Post Run actions/setup-node@v4', 'Post Run actions/checkout@v4', 'Complete job'];
const S2 = mkS(2, [{ v: 'yml', f: ['j'] }, { v: 'yml', f: ['s'] }, { v: 'run', hl: GH_STEPS }, { v: 'three' }]);
function Screen2(p) {
  return <Lesson p={p} S={S2} scene={({ seg }) => <>
    {seg.v === 'yml' && <div className="pg-two"><Yml k="CI_START" title="ci.yml · cicd2-start" ids={{ 3: 'j', 4: 'j', ...rngIds(6, 15, 's') }} focus={seg.f} /><RunView k="c1-10" post /></div>}
    {seg.v === 'run' && <RunView k="c1-10" post hlStep={seg.hl} />}
    {seg.v === 'three' && <div className="pg-three">
      <Card c={C1.ci} h="run"><p>{t("bitta push → bitta run: yashil / qizil, commit xabari, soniya", "один push → один run: зелёный / красный, сообщение commit, секунды")}</p></Card>
      <Card c={T.green} h="job"><p><code>jobs:</code>{t(" ostidagi har nom — alohida mashina; ", " каждое имя под ним — отдельная машина; ")}<code>needs</code>{t(" tartib beradi", " задаёт порядок")}</p></Card>
      <Card c={C1.yml} h="step"><p>{t("har ", "каждый ")}<code>uses</code> / <code>run</code>{t(" — «Run …» qatori; + GitHub qo'shganlari: Set up job · Post Run · Complete job", " — строка «Run …»; + добавленные GitHub: Set up job · Post Run · Complete job")}</p></Card>
    </div>}
  </>} />;
}

// ============================================================
//  3 · uses ichida: Set up job, checkout, setup-node loglari (run 10 — aynan)
// ============================================================
const L3_SETUP = runLog('c1-10', 'Set up job', (l) => /Current runner version|^Image:|^Contents:|Download action repository/.test(l));
const L3_CHECKOUT = runLog('c1-10', 'Run actions/checkout@v4', (l) => /Syncing repository|Deleting the contents|git init|fetch --no-tags/.test(l)).map((l) => ({ ...l, t: l.t.replace(/\[command\]\/usr\/bin\//, '$ ').replace(/ origin \+[0-9a-f]+:.*$/, ' origin +ef9e667…') }));
const L3_NODE = runLog('c1-10', 'Run actions/setup-node@v4', (l) => /^\s+node-version:|^\s+cache:|Found in cache|^node: |^npm: /.test(l));
const S3 = mkS(3, [{ v: 'setup' }, { v: 'checkout' }, { v: 'node' }, { v: 'sum' }]);
function Screen3(p) {
  return <Lesson p={p} S={S3} scene={({ seg }) => <>
    {seg.v === 'setup' && <RunView k="c1-10" open="Set up job" lines={L3_SETUP} hlStep="Set up job" only={/Set up job|checkout|setup-node|npm ci/} />}
    {seg.v === 'checkout' && <RunView k="c1-10" open="Run actions/checkout@v4" lines={L3_CHECKOUT} hlStep="Run actions/checkout@v4" only={/Set up job|checkout|setup-node|npm ci/} />}
    {seg.v === 'node' && <RunView k="c1-10" open="Run actions/setup-node@v4" lines={L3_NODE} hlStep="Run actions/setup-node@v4" only={/Set up job|checkout|setup-node|npm ci/} />}
    {seg.v === 'sum' && <div className="pg-three">
      <Card c={C1.ci} h="Set up job"><p>runner: <code>ubuntu-26.04</code> · <code>GITHUB_TOKEN</code> — <code>Contents: read</code>{t(" · action'lar yuklab olinadi (SHA bilan)", " · скачиваются action (с SHA)")}</p></Card>
      <Card c={T.green} h="checkout"><p>{t("papka tozalanadi → ", "папка очищается → ")}<code>git init</code> → <code>fetch --depth=1</code>{t(" — faqat oxirgi commit", " — только последний commit")}</p></Card>
      <Card c={C1.yml} h="setup-node"><p><code>Found in cache</code>{t(" — runner'dagi tayyor Node · ", " — готовый Node на runner · ")}<code>node: v24.22.1</code> · <code>npm: 11.19.1</code></p></Card>
    </div>}
  </>} />;
}

// ============================================================
//  4 · Qizil run'ni o'qish: annotatsiya qisqa, sabab — qadam logida (run 15 tsc, run 11 test)
// ============================================================
const L4_TSC = runLog('c1-15', 'Run npx tsc --noEmit', (l) => /^\$|error TS|Types of property|Type 'number'/.test(l));
const L4_TEST = runLog('c1-11', 'Run npm test', (l) => /^\$|^FAIL|●|Kolonka|> 37|^Tests:|##\[error\]/.test(l));
const ORDER4 = ['Belgi: run qizil', 'Chapda qizil job', 'Qizil qadam (✗)', 'Qadam logi — sabab shu yerda', '##[error] satrlari → annotatsiya (qisqa)'];
const S4 = mkS(4, [{ v: 'ann' }, { v: 'log' }, { v: 'test' }, { v: 'order' }]);
function Screen4(p) {
  return <Lesson p={p} S={S4} scene={({ seg }) => <>
    {seg.v === 'ann' && <RunView k="c1-15" annAll only={/^Run np/} hlStep="Run npx tsc --noEmit" />}
    {seg.v === 'log' && <RunView k="c1-15" ann={null} only={/^Run np/} open="Run npx tsc --noEmit" lines={L4_TSC} hlStep="Run npx tsc --noEmit" />}
    {seg.v === 'test' && <RunView k="c1-11" only={/^Run np/} open="Run npm test" lines={L4_TEST} hlStep="Run npm test" />}
    {seg.v === 'order' && <div className="mk-light" style={{ padding: 16 }}><div className="mk-tag">{t("Qizil run'ni o'qish tartibi", "Порядок чтения красного run")}</div><div className="mk-plan">{ORDER4.map((x, i) => <div key={i} className={i === 3 ? 'hl' : ''} style={{ animation: `mk-up .4s ${i * 0.1}s ease both` }}><b>0{i + 1}</b><span>{x}</span></div>)}</div></div>}
  </>} />;
}

// ============================================================
//  5 · Tekshiruv 1 — annotatsiya «exit code 1» (run 11)
// ============================================================
function Screen5(p) {
  return MC(p, 5, {
    above: <RunView k="c1-11" only={/^Run np/} hlStep="Run npm test" />,
    after: <RunView k="c1-11" ann={null} only={/npm test/} open="Run npm test" lines={L4_TEST} />,
  });
}

// ============================================================
//  6 · Cache: saqlandi → tiklandi → main'da yo'q (run 10, 11, 18)
// ============================================================
const KEY6 = ((KOD.RUNS['c1-10'].log['Post Run actions/setup-node@v4'] || []).find((l) => /Cache saved with the key/.test(l)) || '').replace(/.*key: /, '');
const S6 = mkS(6, [{ hl: 0 }, { hl: 1 }, { hl: 2 }, { v: 'key' }]);
function Screen6(p) {
  return <Lesson p={p} S={S6} scene={({ seg }) => <>
    <CacheChain hl={seg.v === 'key' ? null : seg.hl} />
    {seg.v === 'key' && <div className="mk-light" style={{ padding: 12, marginTop: 10 }}><div className="mk-tag">{t("Cache kaliti", "Ключ cache")}</div>
      <div style={{ display: 'grid', gap: 6 }}>
        {[['node-cache', t('setup-node yaratgan cache', "cache, созданный setup-node")], ['Linux-x64', t('runner mashinasi', "машина runner")], ['npm', t('paket menejeri', "менеджер пакетов")], [KEY6.replace(/^node-cache-Linux-x64-npm-/, '').slice(0, 12) + '…', t('package-lock.json ning hash\'i — lock o\'zgarsa kalit o\'zgaradi', "хеш package-lock.json — если lock меняется, меняется и ключ")]].map(([a, b], i) => <div key={a} className="c1-code" style={{ animation: `mk-up .35s ${i * 0.08}s ease both` }}><span className="n" style={{ fontSize: 12, color: T.accent }}>{i + 1}</span><span className="t"><code>{a}</code> — {b}</span></div>)}
      </div>
      <div className="mk-rule" style={{ marginTop: 8 }}>Cache — <b>{t("tezlik", "скорость")}</b>{t(", to'g'rilik emas: «not found» xato emas, «hit» — lock o'zgarmagan.", ", а не правильность: «not found» — не ошибка, «hit» — lock не менялся.")}</div>
    </div>}
  </>} />;
}

// ============================================================
//  7 · Amaliyot 1 — o'z run'ingizni o'qish
// ============================================================
const P7 = mkPractice(7, [[], [0, 1], [2, 3], []]);
function ScreenP7(p) { return <Practice p={p} S={P7.S} steps={P7.steps} trouble={P7.trouble} proof={P7.proof} tree={FILES()} />; }
