
// ============================================================
//  1 · Kirish — dars oxiridagi natija: main'dagi yashil run (cicd1-done, run 18)
// ============================================================
const PLAN1 = ['Umumiy tushuncha', "Lenta qo'lda", 'GitHub Actions', "To'rt tuzoq", 'Mashina farqi va AI', 'CD va sinfga tayyorgarlik'];
const S1 = mkS(1, [{ hl: [], res: true }, { hl: [0, 1, 2, 3] }, { hl: [4, 5] }, { hl: [5] }], { plan: PLAN1 });
function Screen1(p) {
  return <Lesson p={p} S={S1} scene={({ seg }) => <div style={{ display: 'grid', gap: 14 }}>
    <div className="mk-light"><div className="mk-plan">
      {S1.plan.map((x, i) => <div key={i} className={seg.hl.includes(i) ? 'hl' : (seg.hl.length ? 'dim' : '')}><b>0{i + 1}</b><span>{x}</span></div>)}
    </div></div>
    {seg.res && <><div className="mk-tag" style={{ margin: 0 }}>{t("Dars oxirida — OrderBotNest main'ida har push'da shu run", "В конце урока — в main OrderBotNest при каждом push такой run")}</div><RunView k="18" only={/^Run /} /></>}
  </div>} />;
}

// ============================================================
//  2 · CI/CD nima qiladi: «menda ishlaydi» → «toza mashinada ishlaydi» (umumiy tushuncha — F-1104 foydalanuvchi talabi)
// ============================================================
const S2 = mkS(2, [{ v: 'now' }, { v: 'ci' }, { v: 'cicd' }, { v: 'today' }]);
function Screen2(p) {
  return <Lesson p={p} S={S2} scene={({ seg }) => <>
    {(seg.v === 'now' || seg.v === 'ci') && <div className="pg-two">
      <Card c={T.accent} h={t("Hozir — «menda ishlaydi»", "Сейчас — «у меня работает»")} hl={seg.v === 'now'} dim={seg.v === 'ci'}>
        <p><b>Siz:</b> <code>npm test</code>{t(" → yashil → ", " → зелёный → ")}<code>git push</code></p>
        <p><b>{t("Hamkor:", "Коллега:")}</b> <code>git clone</code> → <code>npm test</code> → <span style={{ color: T.accent, fontWeight: 700 }}>{t("qizil", "красный")}</span></p>
        <p style={{ marginTop: 6 }}>{t("Kod bir xil, mashina boshqa: ", "Код тот же, машина другая: ")}<code>node_modules</code>{t(" boshqa · Node boshqa · ", " другие · Node другая · ")}<code>.env</code>{t(" boshqa", " другой")}</p>
      </Card>
      <Card c={C1.ci} h={t("Lenta bilan — CI", "С конвейером — CI")} hl={seg.v === 'ci'} dim={seg.v === 'now'}>
        <p><code>git push</code>{t(" → GitHub'dagi ", " → на GitHub ")}<b>{t("toza mashina", "чистая машина")}</b> → <code>npm ci</code> · <code>tsc</code> · <code>test</code> · <code>build</code></p>
        <p style={{ marginTop: 6 }}>{t("Javob hammaga bir xil: ", "Ответ для всех один: ")}<span style={{ color: T.green, fontWeight: 700 }}>{t("yashil", "зелёный")}</span>{t(" yoki ", " или ")}<span style={{ color: T.accent, fontWeight: 700 }}>{t("qizil", "красный")}</span>{t(". Bahs yo'q.", ". Спора нет.")}</p>
      </Card>
    </div>}
    {seg.v === 'cicd' && <div className="pg-two">
      <Card c={C1.ci} h="CI — Continuous Integration"><p>{t("Har push'da toza mashinada ", "При каждом push на чистой машине ")}<b>{t("tekshirish", "проверка")}</b>{t(": o'rnatish → turlar → test → build. Natija: yashil / qizil.", ": установка → типы → тест → build. Результат: зелёный / красный.")}</p></Card>
      <Card c={C1.cd} h="CD — Continuous Delivery / Deployment"><p>{t("Tekshirilgan yukni ", "Проверенный груз — ")}<b>{t("chiqarish", "выпустить")}</b>.</p><p><b>Delivery</b>{t(" — paket tayyor, odam tugmani bosadi.", " — пакет готов, человек нажимает кнопку.")}</p><p><b>Deployment</b>{t(" — lenta o'zi chiqaradi, odam yo'q.", " — конвейер выпускает сам, без человека.")}</p><p style={{ marginTop: 4, color: T.ink3 }}>{t("Ikkalasi CI'dan keyin — qizil yuk chiqmaydi.", "Оба после CI — красный груз не выходит.")}</p></Card>
    </div>}
    {seg.v === 'today' && <div className="mk-light" style={{ padding: 16 }}>
      <div className="mk-tag">{t("Bugun", "Сегодня")}</div>
      <div className="c1-cd">
        <div style={{ '--c': C1.ci }}><h4>{t("CI — to'liq", "CI — полностью")}</h4><p>{t("OrderBotNest: har push'da to'rt qadam, yashil yoki qizil", "OrderBotNest: при каждом push четыре шага, зелёный или красный")}</p></div>
        <div style={{ '--c': C1.ci }}><h4>ci.yml</h4><p>{t("push → run → job → qadam → log", "push → run → job → шаг → лог")}</p></div>
        <div style={{ '--c': C1.cd }}><h4>{t("CD — chegaragacha", "CD — до границы")}</h4><p><code>node dist/main</code>{t(" bazasiz va tokensiz chiqmaydi (22-ekran)", " без базы и токена не выпускается (экран 22)")}</p></div>
        <div className="dim" style={{ '--c': C1.cd }}><h4>Secrets · server</h4><p>{t("keyingi mentor darsi", "следующий урок для менторов")}</p></div>
      </div>
    </div>}
  </>} />;
}

// ============================================================
//  3 · Lenta: to'rt qadam, chiqish kodi, qizilda to'xtaydi
// ============================================================
const CODES3 = [['0', T.green, 'yashil — buyruq tugadi, xato yo\'q', 'npm ci · tsc · npm test · npm run build (01)'], ['1', T.accent, 'qizil — Jest: test yiqildi', 'npm test → FAIL … [chiqish kodi: 1] (02)'], ['2', T.accent, 'qizil — tsc: tur xatosi', 'npx tsc --noEmit → error TS2322 (06)'], ['127', T.accent, 'qizil — buyruq topilmadi', 'sh: 1: jest: not found (04)']];
const S3 = mkS(3, [{ v: 'lenta' }, { v: 'lenta', q: true }, { v: 'codes' }, { v: 'stop' }]);
function Screen3(p) {
  return <Lesson p={p} S={S3} scene={({ seg }) => <>
    {seg.v === 'lenta' && <div className="mk-light" style={{ padding: 14 }}><div className="mk-tag">{t("Lenta — OrderBotNest'ning to'rt qadami", "Конвейер — четыре шага OrderBotNest")}</div><Lenta4 q={seg.q} /></div>}
    {seg.v === 'codes' && <div style={{ display: 'grid', gap: 8 }}>
      <Lenta4 q />
      {CODES3.map(([n, c, tx, ex], i) => <div key={n} className="c1-code" style={{ animation: `mk-up .35s ${i * 0.08}s ease both` }}><span className="n" style={{ color: c }}>{n}</span><span className="t">{tx}<br /><code>{ex}</code></span></div>)}
    </div>}
    {seg.v === 'stop' && <div style={{ display: 'grid', gap: 10 }}>
      <Lenta4 st={{ ci: 'ok', tsc: 'ok', test: 'bad', build: 'skip' }} hl={['test']} />
      <div className="mk-rule">{t("Birinchi ", "На первом ")}<b>{t("qizil", "красном")}</b>{t(" qadamda lenta to'xtaydi: ", " шаге конвейер останавливается: ")}<code>npm test</code>{t(" 1 berdi → ", " вернул 1 → ")}<code>npm run build</code> <b>{t("yurmadi", "не запустился")}</b>{t(". Buzuq kod yig'ilmaydi.", ". Сломанный код не собирается.")}</div>
    </div>}
  </>} />;
}

// ============================================================
//  4 · Toza clone: OrderBotNest'ni qo'lda lentadan o'tkazamiz (cicd1v2-out/01, 07)
// ============================================================
const T4A = outRange('01', /^# Toza/, /^tsconfig/);
const T4B = outRange('01', /^\$ npm ci/, /chiqish kodi: 0 · 2\.6/, (l) => !/^npm warn/.test(l));
const T4C = outRange('01', /^\$ npm test/, null, (l) => !/^(Snapshots|Ran all|Time:|> jest|> order-bot|api|config|core|infrastructure|main\.d\.ts|main\.js\.map|tsconfig\.tsbuildinfo)$|^> order-bot/.test(l));
const DUR4 = { ci: '5.7 s', tsc: '2.6 s', test: '2.2 s', build: '3.5 s' };
const S4 = mkS(4, [{ v: 'ls' }, { v: 'ci' }, { v: 'test' }, { v: 'lenta' }]);
function Screen4(p) {
  return <Lesson p={p} S={S4} scene={({ seg }) => <>
    {seg.v === 'ls' && <Term title={t("VS Code terminali · OrderBotNest (yangi clone, jest2-done)", "терминал VS Code · OrderBotNest (новый clone, jest2-done)")} lines={T4A} />}
    {seg.v === 'ci' && <Term title={t("VS Code terminali · OrderBotNest", "терминал VS Code · OrderBotNest")} lines={T4B} />}
    {seg.v === 'test' && <Term title={t("VS Code terminali · OrderBotNest", "терминал VS Code · OrderBotNest")} lines={T4C} />}
    {seg.v === 'lenta' && <div style={{ display: 'grid', gap: 10 }}>
      <Lenta4 st={{ ci: 'ok', tsc: 'ok', test: 'ok', build: 'ok' }} dur={DUR4} />
      <div className="mk-rule">{t("To'rt buyruq · jami ", "Четыре команды · всего ")}<b>{t("≈ 15 soniya", "≈ 15 секунд")}</b>{t(" · to'rtala chiqish kodi ", " · все четыре кода выхода ")}<b>0</b>{t(" — lenta yashil. GitHub'dagi mashina har push'da aynan shuni qiladi.", " — конвейер зелёный. Машина на GitHub при каждом push делает ровно это.")}</div>
    </div>}
  </>} />;
}

// ============================================================
//  5 · Tekshiruv 1 — jest: not found (cicd1v2-out/04, 01)
// ============================================================
function Screen5(p) {
  return MC(p, 5, {
    above: <div style={{ display: 'grid', gap: 8 }}>
      <Term title={t("VS Code terminali · toza clone, npm ci yurmagan", "терминал VS Code · чистый clone, npm ci не запускался")} lines={out('04')} er />
      <div className="mk-pair"><code>ls</code> → 7 ta: <code>package.json</code> · <code>package-lock.json</code> · <code>src</code> … — <b>{t("node_modules yo'q", "нет node_modules")}</b></div>
    </div>,
    after: <Term title={t("VS Code terminali · npm ci", "терминал VS Code · npm ci")} lines={outRange('01', /^\$ npm ci/, /chiqish kodi: 0 · 5\.7/, (l) => !/^npm warn/.test(l))} />,
  });
}

// ============================================================
//  6 · Test qizil — zanjir shu yerda to'xtaydi (order.service.ts 36 · cicd1v2-out/02)
// ============================================================
const EDIT36 = { 36: '        if (p.stock <= c.qty) {' };
const T6A = outRange('02', /^\$ npm ci/, /^tsc ✓/);
const T6B = outPick('02', (l) => /^\$|✓|^FAIL|●|Kolonka|36 \||> 37|^Tests:|chiqish kodi/.test(l));
const S6 = mkS(6, [{ v: 'code' }, { v: 'chain' }, { v: 'run' }, { v: 'lenta' }]);
function Screen6(p) {
  return <Lesson p={p} S={S6} scene={({ seg }) => <>
    {seg.v === 'code' && <Code k="ORDER_36" files={FILES()} active={F.ord} ids={{ 36: 'x' }} edit={EDIT36} focus={['x']} />}
    {seg.v === 'chain' && <><CodePanel file={t("order.service.ts · buzilgan", "order.service.ts · сломан")} lines={kod('ORDER_36', { 36: 'x' }, 35, 38, EDIT36)} focus={['x']} /><Term lines={T6A} /></>}
    {seg.v === 'run' && <Term title={t("VS Code terminali · npm ci && npx tsc --noEmit && npm test && npm run build", "терминал VS Code · npm ci && npx tsc --noEmit && npm test && npm run build")} lines={T6B} er />}
    {seg.v === 'lenta' && <div style={{ display: 'grid', gap: 10 }}>
      <Lenta4 st={{ ci: 'ok', tsc: 'ok', test: 'bad', build: 'skip' }} hl={['test']} />
      <div className="mk-rule"><code>&amp;&amp;</code>{t(" zanjiri birinchi qizilda uziladi — GitHub lentasi ham: yurmagan qadamni ", " цепочка рвётся на первом красном — конвейер GitHub тоже: незапущенный шаг он показывает как ")}<b>skipped</b>{t(" deb ko'rsatadi. Tiklash: ", " . Восстановление: ")}<code>git checkout -- src/api/order/order.service.ts</code></div>
    </div>}
  </>} />;
}

// ============================================================
//  7 · Amaliyot 1 — lentani qo'lda yurgizish
// ============================================================
const P7 = mkPractice(7, [[], [0, 1], [2, 3], []], {
  code: [{ step: 2, file: F.ord, lines: kod('ORDER_36', { 36: 'x' }, 33, 40, EDIT36), copy: false }],
});
function ScreenP7(p) { return <Practice p={p} S={P7.S} steps={P7.steps} trouble={P7.trouble} proof={P7.proof} code={P7.code} tree={FILES()} />; }
