
// ============================================================
//  1 · Kirish — dars oxiridagi natija: panelda «To'landi» va «Rad etildi» (whv2-out/12, 3-surat)
// ============================================================
const PLAN1 = ['Umumiy tushuncha', 'Imzo', 'Takror va rad', 'Buzamiz', 'AI', 'Sinfga tayyorgarlik'];
const S1 = mkS(1, [{ hl: [], res: true }, { hl: [0, 1] }, { hl: [2, 3, 4, 5] }, { hl: [5] }], { plan: PLAN1 });
function Screen1(p) {
  return <Lesson p={p} S={S1} scene={({ seg }) => <div style={{ display: 'grid', gap: 14 }}>
    <div className="mk-light"><div className="mk-plan" style={seg.res ? { gridTemplateColumns: '1fr 1fr' } : undefined}>
      {S1.plan.map((x, i) => <div key={i} className={seg.hl.includes(i) ? 'hl' : (seg.hl.length ? 'dim' : '')}><b>0{i + 1}</b><span>{x}</span></div>)}
    </div></div>
    {seg.res && <><div className="mk-tag" style={{ margin: 0 }}>{t("Dars oxirida — to'lov xizmati xabar yubordi, panel o'zi yangilandi", "В конце урока — платёжный сервис прислал сообщение, панель обновилась сама")}</div><PanelView k="12-3" small label={t("wh-done · haqiqiy brauzer", "wh-done · настоящий браузер")} /></>}
  </div>} />;
}

// ============================================================
//  2 · Kim kimga yuboradi: to'lov xabari (oqim; whv2-out/03 — tana)
// ============================================================
const FLOW2 = [['m', 'Mijoz', 'kartani xizmatga beradi', T.blue], ['x', "To'lov xizmati", 'Payme, Click kabi', C1.ai], ['w', 'POST /payments/webhook', 'tana + X-Signature', T.accent], ['s', 'Server', 'imzo → yozuv', T.green], ['p', 'Panel', "order-changed 'payment'", C1.ws]];
const T2 = outPick('03', (l) => /^→ POST|X-Signature/.test(l));
const S2 = mkS(2, [{ v: 'flow' }, { v: 'two' }, { v: 'ws' }, { v: 'body' }]);
function Screen2(p) {
  return <Lesson p={p} S={S2} scene={({ seg }) => <>
    {seg.v === 'flow' && <Flow items={FLOW2} hl={['x', 'w']} />}
    {seg.v === 'two' && <div style={{ display: 'grid', gap: 12 }}><Flow items={FLOW2} hl={['x']} /><div className="pg-two">
      <Card c={T.accent} h={t("Mijoz: «to'ladim»", "Клиент: «я оплатил»")}><p>{t("skrinshot, botdagi tugma — ", "скриншот, кнопка в боте — ")}<b>{t("dalil emas", "не доказательство")}</b>{t(": uni har kim yasaydi", ": такое может сделать кто угодно")}</p></Card>
      <Card c={T.green} h={t("Xizmat: imzoli xabar", "Сервис: подписанное сообщение")} hl><p>{t("pul o'tganini xizmat biladi — ", "прошли ли деньги, знает сервис — ")}<b>{t("dalil faqat shu", "доказательство только это")}</b>{t(", imzo bilan", ", с подписью")}</p></Card>
    </div></div>}
    {seg.v === 'ws' && <div className="pg-two">
      <Card c={C1.ws} h="WebSocket"><p>{t("server → panel: server o'zi xabar beradi", "сервер → панель: сервер сообщает сам")}</p></Card>
      <Card c={T.accent} h="Webhook" hl><p>{t("tashqi xizmat → server: xizmat o'zi yuboradi, server ", "внешний сервис → сервер: сервис шлёт сам, сервер ")}<b>{t("kutadi", "ждёт")}</b>{t(" — manzil internetda ochiq", " — адрес открыт в интернете")}</p></Card>
    </div>}
    {seg.v === 'body' && <div style={{ display: 'grid', gap: 10 }}><Term title={t("xabar — tana va imzo sarlavhasi (03)", "сообщение — тело и заголовок подписи (03)")} lines={T2} /><div className="mk-rule">{t("Tanada to'rt maydon: ", "В теле четыре поля: ")}<code>paymentId</code> · <code>orderId</code> · <code>status</code> · <code>amount</code>{t(". Sarlavhada — imzo.", ". В заголовке — подпись.")}</div></div>}
  </>} />;
}

// ============================================================
//  3 · wh-start: manzil yo'q — 404 (whv2-out/01)
// ============================================================
const T3A = outRange('01', /^\$ curl/, /^\$ psql/);
const T3B = outRange('01', /^\$ psql/, null);
const S3 = mkS(3, [{ v: 'a' }, { v: 'b' }, { v: 'open' }, { v: 'need' }]);
function Screen3(p) {
  return <Lesson p={p} S={S3} scene={({ seg }) => <>
    {seg.v === 'a' && <Term title={t("VS Code terminali · wh-start", "терминал VS Code · wh-start")} lines={T3A} er />}
    {seg.v === 'b' && <div style={{ display: 'grid', gap: 8 }}><Term title={t("VS Code terminali · wh-start", "терминал VS Code · wh-start")} lines={T3A} er /><Term title={t("psql · buyurtma", "psql · заказ")} lines={T3B} /></div>}
    {seg.v === 'open' && <div className="pg-two"><Card c={T.green} h={t("To'lov xizmati", "Платёжный сервис")}><p>{t("to'g'ri xabar yuboradi", "шлёт правильное сообщение")}</p></Card><Card c={T.accent} h={t("Istalgan odam", "Кто угодно")} hl><p>{t("xuddi shu manzilga «#1 to'landi» yubora oladi — manzil ", "может прислать на этот же адрес «#1 оплачен» — адрес ")}<b>{t("ochiq", "открыт")}</b></p></Card></div>}
    {seg.v === 'need' && <div className="pg-three">{[[t('1 · Manzil', "1 · Адрес"), 'POST /payments/webhook'], [t('2 · Imzo', "2 · Подпись"), t("xabar haqiqatan xizmatdanmi", "действительно ли сообщение от сервиса")], [t('3 · Bir martalik yozuv', "3 · Одна запись"), t("ikki marta kelsa ham — bir qator", "даже если пришло дважды — одна строка")]].map(([h, tx]) => <Card key={h} c={T.green} h={h}><p>{tx}</p></Card>)}</div>}
  </>} />;
}

// ============================================================
//  4 · Imzo: xom tana + kalit → HMAC (signature.ts, .env.example)
// ============================================================
const SG = { s0: lineN('SIG', /^export function sign\(/), v0: lineN('SIG', /^export function isValidSignature\(/), chk: lineN('SIG', /if \(!secret \|\| !rawBody/), eq: lineN('SIG', /timingSafeEqual\(got, expected\)/) };
const ENV4 = lineN('ENV', /^PAYMENT_WEBHOOK_SECRET=/);
const S4 = mkS(4, [{ v: 'key' }, { v: 'sign' }, { v: 'chk' }, { v: 'eq' }]);
function Screen4(p) {
  return <Lesson p={p} S={S4} scene={({ seg }) => <>
    {seg.v === 'key' && <div style={{ display: 'grid', gap: 8 }}><div className="pg-two"><Card c={C1.ai} h={t("To'lov xizmati", "Платёжный сервис")}><p>{t("kabinetida — kalit", "в своём кабинете — ключ")}</p></Card><Card c={T.green} h={t("Bizning server", "Наш сервер")}><p><code>.env</code>{t(" da — o'sha kalit", " — тот же ключ")}</p></Card></div><CodePanel file=".env.example" lines={kod('ENV', { [ENV4]: 'k', [ENV4 - 1]: 'k', [ENV4 - 2]: 'k' }, ENV4 - 2, ENV4)} focus={['k']} /></div>}
    {seg.v === 'sign' && <Code k="SIG" ids={rngIds(SG.s0, SG.s0 + 2, 's')} from={1} to={SG.s0 + 2} focus={['s']} />}
    {seg.v === 'chk' && <Code k="SIG" ids={rngIds(SG.chk - 1, SG.chk, 'c')} from={SG.v0} to={SG.chk} focus={['c']} />}
    {seg.v === 'eq' && <Code k="SIG" ids={rngIds(SG.eq - 1, SG.eq, 'e')} from={SG.v0} to={SG.eq + 1} focus={['e']} />}
  </>} />;
}

// ============================================================
//  5 · Controller: imzo, maydonlar, yozuv — shu tartibda (payment.controller.ts, main.ts, whv2-out/02)
// ============================================================
const CT = { post: lineN('CTRL', /@Post\('webhook'\)/), iff: lineN('CTRL', /^\s+if \($/, lineN('CTRL', /@Post\('webhook'\)/)), parse: lineN('CTRL', /const p = parsePayment/), rec: lineN('CTRL', /const r = await this\.payments\.record/), ret: lineN('CTRL', /return \{ ok: true/) };
const MN = lineN('MAIN', /NestFactory\.create\(AppModule/);
const T5 = outPick('02', (l) => /main\.ts:|Mapped \{\/payments|ishlayapti/.test(l));
const S5 = mkS(5, [{ v: 'sig' }, { v: 'rec' }, { v: 'main' }, { v: 'order' }]);
function Screen5(p) {
  return <Lesson p={p} S={S5} scene={({ seg }) => <>
    {seg.v === 'sig' && <Code k="CTRL" ids={rngIds(CT.iff, CT.iff + 5, 's')} from={CT.post - 1} to={CT.iff + 5} focus={['s']} />}
    {seg.v === 'rec' && <Code k="CTRL" ids={{ [CT.parse]: 'r', [CT.rec]: 'r', [CT.ret]: 'r' }} from={CT.iff} to={CT.ret + 1} focus={['r']} />}
    {seg.v === 'main' && <div style={{ display: 'grid', gap: 8 }}><CodePanel file="src/main.ts" lines={kod('MAIN', { [MN]: 'm', [MN - 1]: 'm' }, MN - 1, MN + 1)} focus={['m']} /><Term title={t("server logi · npm run start (02)", "лог сервера · npm run start (02)")} lines={T5} /></div>}
    {seg.v === 'order' && <div className="pg-three">{[[t('1 · Imzo', "1 · Подпись"), t("yo'q / noto'g'ri — 401, hech narsa yozilmaydi", "нет / неверная — 401, ничего не записывается"), T.accent], [t('2 · Maydonlar', "2 · Поля"), "paymentId, orderId, status, amount — 400", '#B7791F'], [t('3 · Yozuv', "3 · Запись"), t("faqat shundan keyin — payments va orders", "только после этого — payments и orders"), T.green]].map(([h, tx, c]) => <Card key={h} c={c} h={h}><p>{tx}</p></Card>)}</div>}
  </>} />;
}

// ============================================================
//  6 · Tekshiruv 1 — imzosiz xabar (whv2-out/05)
// ============================================================
const T6 = outRange('05', /^\$ npm run pay -- \d+ imzosiz/, /^\$ npm run pay -- \d+ soxta/);
function Screen6(p) {
  return MC(p, 6, {
    above: <CodePanel file="payment.controller.ts · webhook()" lines={kod('CTRL', rngIds(CT.iff, CT.rec, 'c'), CT.iff, CT.rec)} focus={['c']} />,
    after: <Term title={t("VS Code terminali · npm run pay -- 1 imzosiz (05)", "терминал VS Code · npm run pay -- 1 imzosiz (05)")} lines={T6} />,
  });
}

// ============================================================
//  7 · Haqiqiy oqim: npm run pay → panelda «To'landi» (pay.js; whv2-out/03, 12)
// ============================================================
const PY = { sg: lineN('PAY', /^const sign = /), fe: lineN('PAY', /const r = await fetch\(`\$\{url\}\/payments\/webhook`/) };
const T7A = outRange('03', /^\$ npm run pay/, /^## Server/);
const T7L = outPick('03', (l) => /LOG \[Payment\] pay_/.test(l));
const T7DB = outRange('03', /^\$ psql/, null);
const T7EV = KOD.OUT['12'].split('\n').filter((l) => /"reason":"payment"/.test(l)).slice(0, 1).map((l) => ({ h: liveLine(ms(l)) }));
const S7 = mkS(7, [{ v: 'pay' }, { v: 'run' }, { v: 'db' }, { v: 'panel' }]);
function Screen7(p) {
  return <Lesson p={p} S={S7} scene={({ seg }) => <>
    {seg.v === 'pay' && <Code k="PAY" ids={{ ...rngIds(PY.sg, PY.sg, 'p'), ...rngIds(PY.fe, PY.fe + 1, 'p') }} from={PY.sg} to={PY.fe + 4} focus={['p']} />}
    {seg.v === 'run' && <div style={{ display: 'grid', gap: 8 }}><Term title={t("VS Code terminali · npm run pay -- 1", "терминал VS Code · npm run pay -- 1")} lines={T7A} /><Term title={t("server logi", "лог сервера")} lines={T7L} /></div>}
    {seg.v === 'db' && <Term title={t("psql · payments va orders (03)", "psql · payments и orders (03)")} lines={T7DB} />}
    {seg.v === 'panel' && <div style={{ display: 'grid', gap: 8 }}><PanelView k="12-1" small label={t("to'lovdan oldin", "до оплаты")} /><PanelView k="12-2" small label={t("to'lovdan keyin — sahifa yangilanmadi", "после оплаты — страница не обновлялась")} /><Term title={t("panel logi", "лог панели")} lines={T7EV} /></div>}
  </>} />;
}

// ============================================================
//  8 · Amaliyot 1 — webhook va soxta to'lov xizmati
// ============================================================
const P8 = mkPractice(8, [[], [0, 1], [2, 3], []], {
  code: [{ step: 1, file: F.env, lines: kod('ENV', { [ENV4]: 'k' }, ENV4 - 2, ENV4) }, { step: 3, file: F.pay, lines: kod('PAY'), copy: false }],
});
function ScreenP8(p) { return <Practice p={p} S={P8.S} steps={P8.steps} trouble={P8.trouble} proof={P8.proof} code={P8.code} tree={FILES()} />; }
