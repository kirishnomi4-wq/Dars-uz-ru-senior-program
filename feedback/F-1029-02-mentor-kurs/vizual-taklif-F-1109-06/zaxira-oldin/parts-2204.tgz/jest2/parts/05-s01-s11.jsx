
// ============================================================
//  1 · Kirish — dars oxiridagi natija: 5 fayl, 25 test (jest2v2-out/12)
// ============================================================
const PLAN1 = ['Umumiy tushuncha', 'Telefon: edge case', 'Buyurtma: error path', "Chegara va «bo'lmasligi kerak»", 'HTTP test va AI', 'Sinfga tayyorgarlik'];
const S1 = mkS(1, [{ hl: [], res: true }, { hl: [0] }, { hl: [1, 2, 3, 4] }, { hl: [5] }], { plan: PLAN1 });
const T1 = outPick('12', (l) => /^(PASS|Tests:|Time:)/.test(l));
function Screen1(p) {
  return <Lesson p={p} S={S1} scene={({ seg }) => <div style={{ display: 'grid', gap: 14 }}>
    <div className="mk-light"><div className="mk-plan">
      {S1.plan.map((x, i) => <div key={i} className={seg.hl.includes(i) ? 'hl' : (seg.hl.length ? 'dim' : '')}><b>0{i + 1}</b><span>{x}</span></div>)}
    </div></div>
    {seg.res && <><div className="mk-tag" style={{ margin: 0 }}>{t("Dars oxirida — OrderBotNest'da 5 ta test fayli, 25 test", "В конце урока — в OrderBotNest 5 тестовых файлов, 25 тестов")}</div>
      <Term title={t("VS Code terminali · npm test -- --verbose", "терминал VS Code · npm test -- --verbose")} lines={T1} /></>}
  </div>} />;
}

// ============================================================
//  2 · Uch yo'l: happy path, edge case, error path (umumiy tushuncha — F-1104 foydalanuvchi talabi)
// ============================================================
const PATHS2 = [
  { k: 'happy', c: JC.happy, h: 'Happy path — kutilgan kirish', ex: ['+998901234567', 'omborda 10 ta'], q: "Buyurtma qabul qilindi. Jest-1 ning hamma testi shu yo'lda edi.", t: "test: natija to'g'rimi" },
  { k: 'edge', c: JC.edge, h: 'Edge case — qoidaning chegarasi', ex: ['+998 90 123 45 67', '9 ta raqam', 'omborda aynan 2 ta'], q: "Kod xato bermaydi — lekin javobi to'g'rimi?", t: "test: chegarada ham to'g'rimi" },
  { k: 'err', c: JC.err, h: 'Error path — kod ataylab xato beradi', ex: ["telefon yo'q", "savat bo'sh", 'omborda 1 ta, savatda 2'], q: "Xato — to'g'ri xulq. Qaysi xabar? Keyin nima bo'lmaydi?", t: "test: xato chiqdi va keyingi qadam bo'lmadi" },
];
const S2 = mkS(2, [{ on: 0 }, { on: 1 }, { on: 2 }, { on: -1, all: true }]);
function Screen2(p) {
  return <Lesson p={p} S={S2} scene={({ seg }) => <div className="pg-three">
    {PATHS2.map((x, i) => <div key={x.k} className={`path${seg.on === i ? ' hl' : ''}${seg.on >= 0 && seg.on !== i ? ' dim' : ''}`} style={{ '--c': x.c }}>
      <h4>{x.h}</h4>{x.ex.map((e) => <div key={e} className="ex">{e}</div>)}<div className="q">{x.q}</div>{seg.all && <div className="t">{x.t}</div>}
    </div>)}
  </div>} />;
}

// ============================================================
//  3 · Telefon qoidasi yashirin — alohida funksiyaga (jest2-start 12, 155–157 · phone.ts · jest2-done 10, 155–156)
// ============================================================
const S3 = mkS(3, [{ v: 'old', f: ['p', 'u'] }, { v: 'old', f: ['p'] }, { v: 'new' }, { v: 'use' }]);
function Screen3(p) {
  return <Lesson p={p} S={S3} scene={({ seg }) => <>
    {seg.v === 'old' && <Ide files={compact(FILES(), F.tg)} active={F.tg}>
      <CodePanel file="telegram.service.ts" lines={[...kod('TS_PHONE', { 12: 'p' }), { h: '<span class="cm">…</span>', n: '' }, ...kod('TS_ONTEXT', { 155: 'u', 156: 'u', 157: 'u' })]} focus={seg.f} />
    </Ide>}
    {seg.v === 'new' && <Code k="PHONE_OLD" files={FILES(F.ph)} active={F.ph} fresh={F.ph} ids={{ 2: 'r', 4: 'i' }} focus={['r', 'i']} />}
    {seg.v === 'use' && <Ide files={compact(FILES(F.ph), F.tg)} active={F.tg}>
      <CodePanel file="telegram.service.ts · jest2-done" lines={[...kod('TS_IMPORT_NEW', { 10: 'i' }), { h: '<span class="cm">…</span>', n: '' }, ...kod('TS_ONTEXT_NEW', { 155: 'u', 156: 'u' }, 153, 158)]} focus={['i', 'u']} />
    </Ide>}
  </>} />;
}

// ============================================================
//  4 · Tekshiruv 1 — probel bilan yozilgan raqam (jest2v2-out/02)
// ============================================================
function Screen4(p) {
  return MC(p, 4, {
    above: <div style={{ display: 'grid', gap: 8 }}>
      <CodePanel file="phone.ts" lines={kod('PHONE_OLD', { 2: 'r', 4: 'i' })} focus={['r', 'i']} />
      <div className="mk-pair">{t("Aziza yozdi: ", "Азиза написала: ")}<code>+998 90 123 45 67</code></div>
    </div>,
    after: <Term title={t("VS Code terminali · npm test -- phone", "терминал VS Code · npm test -- phone")} lines={out('02', outFind('02', /✕/), outFind('02', /Received:/))} er />,
  });
}

// ============================================================
//  5 · Edge testlar: it.each (kod-02-phone.spec.ts · jest2v2-out/02)
// ============================================================
const T5 = out('02', outFind('02', /^FAIL/), outFind('02', /^Tests:/));
const S5 = mkS(5, [{ f: ['a'] }, { f: ['b'] }, { f: ['c'], run: true }, { f: [], run: true, sum: true }]);
function Screen5(p) {
  return <Lesson p={p} S={S5} scene={({ seg }) => <>
    {!seg.run && <Code k="SPEC_PHONE_02" files={FILES(F.ph, F.phs)} active={F.phs} fresh={F.phs} ids={{ ...rngIds(4, 6, 'a'), ...rngIds(8, 15, 'b'), ...rngIds(17, 19, 'c') }} focus={seg.f} />}
    {seg.run && !seg.sum && <><CodePanel file="phone.spec.ts" lines={kod('SPEC_PHONE_02', rngIds(17, 19, 'c'), 17, 20)} focus={seg.f} /><Term title={t("VS Code terminali · npm test -- phone", "терминал VS Code · npm test -- phone")} lines={T5} er /></>}
    {seg.sum && <Term title={t("VS Code terminali · npm test -- phone", "терминал VS Code · npm test -- phone")} lines={out('02', outFind('02', /✕/), outFind('02', /Received:/))} er />}
    {seg.sum && <div className="mk-rule">{t(<>Qoida mijozdan <b>tor</b>: regex faqat raqam va <code>+</code> ni biladi, mijoz probel yozadi.</>, <>Правило <b>уже</b>, чем клиент: regex знает только цифры и <code>+</code>, а клиент пишет пробел.</>)}</div>}
  </>} />;
}

// ============================================================
//  6 · Ichida: tuzatish va «9 ta nol ham o'tadi» (kod-03-phone.ts · jest2v2-out/03, 04)
// ============================================================
const FIX6 = kod('PHONE_OLD', { 4: 'f' }, 1, 4, { 4: KOD.PHONE_NEW.lines[3].t });
const T6A = out('03', outFind('03', /^PASS/), outFind('03', /^Tests:/));
const T6B = out('04', outFind('04', /isPhone — qoida/), outFind('04', /^Tests:/));
const S6 = mkS(6, [{ v: 'fix' }, { v: 'nol' }, { v: 'nol', rule: true }, { v: 'sum' }]);
function Screen6(p) {
  return <Lesson p={p} S={S6} scene={({ seg }) => <>
    {seg.v === 'fix' && <><CodePanel file="phone.ts" lines={FIX6} focus={['f']} /><Term title={t("VS Code terminali · npm test -- phone", "терминал VS Code · npm test -- phone")} lines={T6A} /></>}
    {seg.v === 'nol' && <><CodePanel file="phone.spec.ts" lines={kod('SPEC_PHONE_04', rngIds(22, 25, 'n'), 22, 26)} focus={seg.rule ? [] : ['n']} /><Term title={t("VS Code terminali · npm test -- phone", "терминал VS Code · npm test -- phone")} lines={T6B} /></>}
    {seg.rule && <div className="n2-warn">{t(<>Test <b>qoidani</b> tekshiradi. Qoidaning o'zi to'g'rimi (9 ta nol — telefonmi?) — bu <b>sizning qaroringiz</b>.</>, <>Тест проверяет <b>правило</b>. Верно ли само правило (9 нулей — телефон?) — это <b>ваше решение</b>.</>)}</div>}
    {seg.v === 'sum' && <div className="pg-two">
      <Card c={T.accent} h={t('Qoida tor edi', 'Правило было узким')}><p><code>+998 90 123 45 67</code> → <code>false</code> — {t('probel testi topdi', 'нашёл тест с пробелом')} → <code>replace</code></p></Card>
      <Card c={JC.edge} h={t('Qoida keng', 'Правило широкое')}><p><code>000000000</code> → <code>true</code> — {t("chegara testi ko'rsatdi → sizning qaroringiz", 'показал тест границы → ваше решение')}</p></Card>
    </div>}
  </>} />;
}

// ============================================================
//  7 · Amaliyot 1 — phone.ts va phone.spec.ts
// ============================================================
const P7 = mkPractice(7, [[], [0, 1], [2, 3], []], {
  code: [
    { step: 1, file: F.phs, lines: kod('SPEC_PHONE_02') },
    { step: 2, file: F.ph, lines: kod('PHONE_NEW') },
    { step: 3, file: F.phs, lines: kod('SPEC_PHONE_04') },
  ],
});
function ScreenP7(p) { return <Practice p={p} S={P7.S} steps={P7.steps} trouble={P7.trouble} proof={P7.proof} code={P7.code} tree={FILES(F.ph, F.phs)} />; }

// ============================================================
//  8 · place — uch xato, ikki xil joy (order.service.ts 24–45, jest2-start)
// ============================================================
function Flow8({ hl }) {
  return <div className="mk-light" style={{ padding: 14 }}>
    <div className="mk-tag">{t("place() — xato qayerda otiladi", "place() — где бросается ошибка")}</div>
    <div className="fl-grid">
      <div className="fl-box" style={{ '--c': T.blue }}><small>place(user, cart)</small><b>{t("funksiya chaqirildi", "функция вызвана")}</b></div>
      <div className="fl-tests">
        <div className="fl-row"><span className="fl-ar">→</span><div className={`fl-box${hl === 'sync' ? ' hl' : ''}`} style={{ '--c': JC.err }}><small>{t("25–26-satr · darhol, funksiyaning o'zida", "строки 25–26 · сразу, в самой функции")}</small><b>throw «Telefon raqami yo'q» · «Savat bo'sh»</b></div><div className="fl-v bad">{t("sinxron xato", "синхронная ошибка")}</div></div>
        <div className="fl-row"><span className="fl-ar">→</span><div className={`fl-box${hl === 'async' ? ' hl' : ''}`} style={{ '--c': JC.edge }}><small>{t("27-satr: transaction(async …) → 37-satr", "строка 27: transaction(async …) → строка 37")}</small><b>throw «Kolonka: omborda faqat 1 ta qoldi»</b></div><div className="fl-v bad">{t("promise xatosi", "ошибка promise")}</div></div>
      </div>
    </div>
  </div>;
}
const S8 = mkS(8, [{ v: 'code', f: ['s'] }, { v: 'code', f: ['a'] }, { v: 'flow', hl: 'sync' }, { v: 'flow', hl: 'async', sum: true }]);
function Screen8(p) {
  return <Lesson p={p} S={S8} scene={({ seg }) => <>
    {seg.v === 'code' && <Code k="ORDER_PLACE" files={FILES()} active={F.ord} ids={{ 25: 's', 26: 's', 36: 'a', 37: 'a', 38: 'a' }} focus={seg.f} from={24} to={38} />}
    {seg.v === 'flow' && <Flow8 hl={seg.hl} />}
    {seg.sum && <div className="mk-rule">{t("Sinxron xato — ", "Синхронная ошибка — ")}<code>expect(() =&gt; …).toThrow()</code>{t(" · promise xatosi — ", " · ошибка promise — ")}<code>await expect(…).rejects.toThrow()</code>{t(". Shakl almashsa, Jest qizil ham bermaydi (11, 13-ekran).", ". Если перепутать форму, Jest даже не даст красного (экраны 11, 13).")}</div>}
  </>} />;
}

// ============================================================
//  9 · Mock: baza o'rniga soxta manager (kod-05-order.service.spec.ts 8–31)
// ============================================================
const S9 = mkS(9, [{ f: ['m'], to: 16 }, { f: ['d'], to: 16 }, { f: ['t'], to: 31 }, { f: ['r'], from: 44, to: 50 }]);
function Screen9(p) {
  return <Lesson p={p} S={S9} scene={({ seg }) => <>
    <Code k="SPEC_ORDER_05" files={FILES(F.ph, F.phs, F.ors)} active={F.ors} fresh={F.ors} ids={{ ...rngIds(8, 14, 'm'), 15: 'd', ...rngIds(23, 29, 't'), ...rngIds(45, 50, 'r') }} focus={seg.f} from={seg.from || 1} to={seg.to} />
    {seg.f[0] === 'r' && <div className="mk-rule"><code>mockResolvedValue</code>{t(" — bu testda ", " — в этом тесте ")}<code>findOne</code>{t(" aynan shu mahsulotni qaytaradi: omborda ", " возвращает именно этот товар: на складе ")}<b>1 ta</b>{t(". Baza yo'q, kod haqiqiy.", ". Базы нет, код настоящий.")}</div>}
  </>} />;
}

// ============================================================
//  10 · toThrow va rejects.toThrow — to'rt test yashil (kod-05 33–67 · jest2v2-out/05)
// ============================================================
const T10 = out('05', outFind('05', /^PASS/), outFind('05', /^Tests:/));
const S10 = mkS(10, [{ f: ['s'], to: 42 }, { f: ['a'], from: 44, to: 55 }, { f: ['h'], from: 57, to: 67, run: true }, { run: true, sum: true }]);
function Screen10(p) {
  return <Lesson p={p} S={S10} scene={({ seg }) => <>
    {!seg.sum && <CodePanel file="order.service.spec.ts" lines={kod('SPEC_ORDER_05', { ...rngIds(34, 38, 's'), ...rngIds(40, 42, 's'), ...rngIds(51, 54, 'a'), 65: 'h', 66: 'h' }, seg.from || 33, seg.to)} focus={seg.f} />}
    {seg.run && <Term title={t("VS Code terminali · npm test -- order.service", "терминал VS Code · npm test -- order.service")} lines={T10} />}
    {seg.sum && <div className="pg-two">
      <Card c={JC.err} h={t("Sinxron xato", "Синхронная ошибка")}><p><code>expect(() =&gt; service.place(…)).toThrow('…')</code>{t(" — funksiya o'raladi, Jest o'zi chaqiradi", " — функция обёрнута, Jest вызывает её сам")}</p></Card>
      <Card c={JC.edge} h={t("Promise xatosi", "Ошибка promise")}><p><code>await expect(service.place(…)).rejects.toThrow('…')</code>{t(" — darhol chaqiriladi, promise kutiladi", " — вызывается сразу, promise ожидается")}</p></Card>
    </div>}
  </>} />;
}

// ============================================================
//  11 · Buzamiz: toThrow promise xatosida — natija yo'q (kod-07 · jest2v2-out/07)
// ============================================================
const T11 = out('07');
const CAUSE11 = ["toThrow o'ramni chaqirdi — place() promise qaytardi", "Shu paytda xato yo'q → Jest «test o'tdi» deb hisobladi", "Xato keyin, promise ichida otildi — hech kim ushlamadi", 'Node butun jarayonni to\'xtatdi: PASS ham, FAIL ham yo\'q'];
function Cause({ items, on, bad }) {
  return <div className="cause">{items.map((x, i) => <div key={i} className={`${i < on ? 'on' : ''}${bad === i ? ' bad' : ''}`}><i>{i + 1}</i><span>{x}</span></div>)}</div>;
}
const S11 = mkS(11, [{ v: 'code' }, { v: 'run' }, { v: 'cause' }, { v: 'cause', sum: true }]);
function Screen11(p) {
  return <Lesson p={p} S={S11} scene={({ seg }) => <>
    {seg.v === 'code' && <CodePanel file={t("order.service.spec.ts · buzilgan", "order.service.spec.ts · сломан")} lines={kod('SPEC_ORDER_07', { 51: 'x', 52: 'x', 53: 'x' }, 44, 55)} focus={['x']} />}
    {seg.v === 'run' && <><CodePanel file={t("order.service.spec.ts · buzilgan", "order.service.spec.ts · сломан")} lines={kod('SPEC_ORDER_07', { 51: 'x' }, 51, 53)} focus={['x']} /><Term title={t("VS Code terminali · natija yo'q", "терминал VS Code · результата нет")} lines={T11} er /></>}
    {seg.v === 'cause' && <><Term title={t("VS Code terminali · natija yo'q", "терминал VS Code · результата нет")} lines={T11} er /><Cause items={CAUSE11} on={seg.sum ? 4 : 4} bad={3} /></>}
  </>} />;
}
